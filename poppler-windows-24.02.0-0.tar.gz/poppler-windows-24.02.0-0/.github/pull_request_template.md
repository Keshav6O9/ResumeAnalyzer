Package for poppler v20.**.0

# Checklist:

- [ ] I have confirmed that [poppler-feedstock](https://github.com/conda-forge/poppler-feedstock) has been updated.
- [ ] I have bumped `package.sh` `POPPLER_VERSION` to the current build.
